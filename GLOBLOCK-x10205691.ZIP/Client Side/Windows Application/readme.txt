Client folder contains Source code for Globlock Client Application

